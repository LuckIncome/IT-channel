<div id="block-category">
    <p class="header-title">Категории товаров</p>
    <ul>
        <li>
            <a href="#">
                <img src="/images/mobile-icon.gif" id="mobile-images" />Мобильные телефоны
            </a>
        
            <ul class="category-section">
                <li><a href=""><strong>Все модели</strong> </a></li>
                <li><a href="">Подраздел 1</a></li>
                <li><a href="">Подраздел 2</a></li>
            </ul>
        </li>
        
        <li>
            <a href="#">
                <img src="/images/book-icon.gif" id="book-images" />Ноутбуки
            </a>
        
            <ul class="category-section">
                <li><a href=""><strong>Все модели</strong> </a></li>
                <li><a href="">Подраздел 1</a></li>
                <li><a href="">Подраздел 2</a></li>
            </ul>
        </li>
        
        <li>
            <a href="#">
                <img src="/images/table-icon.gif" id="table-images" />Планшеты
            </a>
        
            <ul class="category-section">
                <li><a href=""><strong>Все модели</strong> </a></li>
                <li><a href="">Подраздел 1</a></li>
                <li><a href="">Подраздел 2</a></li>
            </ul>
        </li>
    </ul>
</div>