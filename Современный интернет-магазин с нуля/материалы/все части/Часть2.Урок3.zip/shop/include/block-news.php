<!--Блок новости-->  
<div id="block-news">
   
    <center><img id="news-prev" src="images/img-prev.png" /></center>
    
    <div id="newsticker">
        <ul>
            <li>
                <span>25.07.2013</span>
                <a href="">Кредит без переплаты на планшет Samsung</a>
                <p>С июля до сентебря во всех салонах-магазина  - планшеты Samsung в кредит без переплат!</p>
            </li>
            
            <li>
                <span>25.07.2013</span>
                <a href="">Кредит без переплаты на планшет Samsung</a>
                <p>С июля до сентебря во всех салонах-магазина  - планшеты Samsung в кредит без переплат!</p>
            </li>
            
            <li>
                <span>25.07.2013</span>
                <a href="">Кредит без переплаты на планшет Samsung</a>
                <p>С июля до сентебря во всех салонах-магазина  - планшеты Samsung в кредит без переплат!</p>
            </li>
        </ul>
    </div>
    
    <center><img id="news-next" src="images/img-next.png" /></center>
    
</div>